<footer>
        <p>Copyright © <?php echo date('Y'); ?> Art Gallery</p>
    </footer>
</body>
</html>