<!DOCTYPE html>
<html>
<head>
    <title>Art Gallery</title>
    <link rel="stylesheet" type="text/css" href="css/styles2.css">
    <script src="js/main.js"></script>



    
</head>
<body>
<header id="header">

<div id="falling-images">

    <nav>
    <a href="index.php?page=submit" id="submit-art-link" style="display: none;">Submit Art</a>
    <a href="index.php?page=logout" id="logout-link" style="display: none;">Logout</a>
    <a href="index.php?page=login" id="login-link">Login</a>
    <a href="index.php?page=signup" id="signup-link">Signup</a>
    <a href="index.php?page=leaderboard" id="signup-link">Leaderboard</a>
    <a href="index.php?page=home" id="home">Gallery</a>
    <a href="index.php?page=dashboard" id="admin-panel-link" style="display: none;">Admin Panel</a>
    <a href="index.php?page=moderation" id="approve-art-link" style="display: none;">Approve Art</a>   
    </nav>


</div>

</header>



